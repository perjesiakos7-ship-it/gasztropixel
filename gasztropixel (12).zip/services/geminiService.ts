import { GoogleGenAI } from "@google/genai";
import { AnalysisResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeFoodImage = async (base64Image: string): Promise<AnalysisResult> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      You are a world-class professional food photographer and retoucher. 
      Analyze the attached image of food. 
      Respond in Hungarian (Magyar).
      
      1. Give a 2-sentence professional critique of the lighting, color, and composition (Feedback).
      2. List 3 specific retouching actions you would take to make this image sell better on Wolt/Foodora (Suggestions).
      
      Return the response as a JSON object with keys "feedback" (string) and "suggestions" (array of strings).
      Do not include markdown code blocks.
    `;

    // Remove header if present (e.g., "data:image/jpeg;base64,")
    const cleanBase64 = base64Image.split(',')[1] || base64Image;

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: cleanBase64
            }
          },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text) as AnalysisResult;

  } catch (error) {
    console.error("Gemini analysis failed:", error);
    return {
      feedback: "Sajnos nem sikerült elemezni a képet. Kérlek próbáld újra később.",
      suggestions: ["Fényerő korrekció", "Színek élénkítése", "Élesség beállítása"]
    };
  }
};