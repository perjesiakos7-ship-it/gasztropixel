import { useState, useRef, useCallback, type FC, type MouseEvent, type TouchEvent } from 'react';
import { MoveHorizontal } from 'lucide-react';

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  alt: string;
  enhanceDemo?: boolean;
}

export const BeforeAfterSlider: FC<BeforeAfterSliderProps> = ({ beforeImage, afterImage, alt, enhanceDemo = false }) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = useCallback((clientX: number) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
      const percentage = (x / rect.width) * 100;
      setSliderPosition(percentage);
    }
  }, []);

  const onMouseDown = () => setIsDragging(true);
  const onMouseUp = () => setIsDragging(false);
  
  const onMouseMove = (e: MouseEvent) => {
    if (isDragging) handleMove(e.clientX);
  };

  const onTouchMove = (e: TouchEvent) => {
    handleMove(e.touches[0].clientX);
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full aspect-[4/3] rounded-xl overflow-hidden cursor-ew-resize select-none shadow-2xl dark:shadow-none dark:border dark:border-zinc-800"
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
      onTouchMove={onTouchMove}
    >
      {/* Before Image (Background) */}
      {/* Removed filters (grayscale, brightness) so the image looks natural */}
      <img 
        src={beforeImage} 
        alt={`Before ${alt}`} 
        className="absolute top-0 left-0 w-full h-full object-cover" 
      />
      <div className="absolute top-4 left-4 bg-black/60 text-white text-xs px-2 py-1 rounded">
        Előtte
      </div>

      {/* After Image (Clipped) */}
      <div 
        className="absolute top-0 left-0 w-full h-full overflow-hidden"
        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
      >
        <img 
          src={afterImage} 
          alt={`After ${alt}`} 
          className="absolute top-0 left-0 w-full h-full object-cover" 
        />
        <div className="absolute top-4 right-4 bg-orange-600/90 text-white text-xs px-2 py-1 rounded z-20">
          Utána
        </div>
      </div>

      {/* Slider Handle */}
      <div 
        className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-10"
        style={{ left: `${sliderPosition}%` }}
        onMouseDown={onMouseDown}
        onTouchStart={onMouseDown}
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg text-orange-600">
          <MoveHorizontal size={20} />
        </div>
      </div>
    </div>
  );
};