
import { useState, type FC, type FormEvent } from 'react';
import { Send, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from './Button';
import emailjs from '@emailjs/browser';
import { EMAIL_CONFIG } from '../services/emailConfig';

export const ContactForm: FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSending, setIsSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setError(null);

    // Aktuális idő formázása (pl. 14:30) a Chat sablonhoz
    const now = new Date();
    const formattedTime = now.toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' });

    // Ellenőrzés: Be vannak-e állítva a kulcsok?
    if (EMAIL_CONFIG.SERVICE_ID.includes("IDE_MASOLD")) {
        console.warn("EmailJS nincs beállítva, szimulált küldés...");
        setTimeout(() => {
            setIsSending(false);
            setSent(true);
            setFormData({ name: '', email: '', message: '' });
            setTimeout(() => setSent(false), 5000);
        }, 1500);
        return;
    }
    
    try {
      await emailjs.send(
        EMAIL_CONFIG.SERVICE_ID,
        EMAIL_CONFIG.ADMIN_TEMPLATE_ID, // A NEKED szóló sablon
        {
          name: formData.name,        
          email: formData.email,      
          from_email: formData.email, 
          message: formData.message,  
          time: formattedTime,        
          to_name: "GasztroPixel"
        },
        EMAIL_CONFIG.PUBLIC_KEY
      );

      setSent(true);
      setFormData({ name: '', email: '', message: '' });
      setTimeout(() => setSent(false), 5000);

    } catch (err) {
      console.error("Email küldési hiba:", err);
      setError("Hiba történt az üzenet küldésekor. Kérlek próbáld újra később.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white dark:bg-zinc-800 p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-zinc-700 transition-colors duration-300">
      {sent ? (
        <div className="text-center py-12 animate-in fade-in zoom-in">
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Üzenet elküldve!</h3>
          <p className="text-gray-600 dark:text-gray-400">
            Köszönjük a megkeresést. Hamarosan válaszolunk a megadott e-mail címen.
          </p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Név</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-colors"
                placeholder="Nagy Gábor"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">E-mail cím</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-colors"
                placeholder="info@pelda.hu"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Üzenet</label>
            <textarea
              required
              rows={4}
              value={formData.message}
              onChange={(e) => setFormData({...formData, message: e.target.value})}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-colors resize-none"
              placeholder="Miben segíthetünk?"
            />
          </div>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-3 rounded-lg flex items-center text-sm border border-red-200 dark:border-red-800">
              <AlertCircle className="w-4 h-4 mr-2" />
              {error}
            </div>
          )}

          <Button type="submit" className="w-full" isLoading={isSending}>
            Üzenet küldése <Send className="w-4 h-4 ml-2" />
          </Button>
        </form>
      )}
    </div>
  );
};
