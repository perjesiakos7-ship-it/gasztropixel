
import { useState, type FC, type ChangeEvent, type FormEvent } from 'react';
import { Upload, CheckCircle, AlertCircle, Search, ArrowRight } from 'lucide-react';
import { Button } from './Button';
import { analyzeFoodImage } from '../services/geminiService';
import { AnalysisResult } from '../types';
import emailjs from '@emailjs/browser';
import { EMAIL_CONFIG } from '../services/emailConfig';

export const TrialForm: FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [image, setImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [email, setEmail] = useState('');
  const [step, setStep] = useState<'upload' | 'analysis' | 'complete'>('upload');
  const [isSending, setIsSending] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Convert to base64
    const reader = new FileReader();
    reader.onloadend = () => {
      setImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setAnalyzing(true);
    const data = await analyzeFoodImage(image);
    setResult(data);
    setAnalyzing(false);
    setStep('analysis');
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setEmailError(null);

    // Ha nincsenek beállítva a kulcsok, csak szimuláljuk
    if (EMAIL_CONFIG.SERVICE_ID.includes("IDE_MASOLD")) {
        console.warn("EmailJS nincs beállítva, szimulált küldés...");
        setTimeout(() => {
            setIsSending(false);
            setStep('complete');
            setTimeout(onComplete, 2000);
        }, 1500);
        return;
    }

    try {
      // E-mail küldése az ADMINNAK (hogy legyen egy lead)
      await emailjs.send(
        EMAIL_CONFIG.SERVICE_ID,
        EMAIL_CONFIG.ADMIN_TEMPLATE_ID,
        {
          name: "PRÓBA RETUS KÉRÉS",
          email: email,
          from_email: email,
          message: `Ügyfél kért egy próba retust. Elemzés: ${result?.feedback}`,
          time: new Date().toLocaleTimeString(),
        },
        EMAIL_CONFIG.PUBLIC_KEY
      );

      setStep('complete');
      setTimeout(onComplete, 3000);
    } catch (error) {
      console.error("Email küldési hiba:", error);
      setEmailError("Hiba történt az e-mail küldésekor. Kérlek próbáld újra, vagy írj nekünk közvetlenül.");
    } finally {
      setIsSending(false);
    }
  };

  if (step === 'complete') {
    return (
      <div className="text-center p-8 bg-green-50 dark:bg-green-900/30 rounded-xl border border-green-200 dark:border-green-800 animate-in fade-in zoom-in duration-300">
        <div className="w-16 h-16 bg-green-100 dark:bg-green-900/50 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle size={32} />
        </div>
        <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Köszönjük!</h3>
        <p className="text-gray-600 dark:text-gray-300">
          A próba-retusálás eredményét és az ajánlatunkat hamarosan elküldjük a(z) <br/>
          <strong>{email}</strong> címre.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-zinc-800 p-6 md:p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-zinc-700 max-w-2xl mx-auto transition-colors duration-300">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Ingyenes Próba-Retusálás</h3>
        <span className="text-xs font-medium px-2 py-1 bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-300 rounded-full">AI Elemzés</span>
      </div>

      {/* Image Preview & Analysis */}
      {image ? (
        <div className="mb-6 space-y-4">
          <div className="relative rounded-lg overflow-hidden h-48 md:h-64 w-full bg-gray-100 dark:bg-zinc-900">
            <img src={image} alt="Preview" className="w-full h-full object-cover" />
            {analyzing && (
              <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center text-white">
                <Search className="animate-pulse w-10 h-10 mb-2" />
                <span>AI Elemzés folyamatban...</span>
              </div>
            )}
          </div>

          {!result && !analyzing && (
            <Button onClick={handleAnalyze} className="w-full">
              <Search className="w-4 h-4 mr-2" />
              Kép Elemzése AI-val
            </Button>
          )}

          {result && (
            <div className="bg-slate-50 dark:bg-zinc-900/50 p-4 rounded-lg border border-slate-200 dark:border-zinc-700">
              <h4 className="font-semibold text-slate-800 dark:text-white mb-2 flex items-center">
                 <AlertCircle className="w-4 h-4 mr-2 text-orange-600" />
                 Szakértői diagnózis:
              </h4>
              <p className="text-slate-600 dark:text-gray-300 text-sm mb-3 italic">"{result.feedback}"</p>
              <h5 className="text-xs font-bold text-slate-500 dark:text-gray-400 uppercase tracking-wide mb-2">Javasolt beavatkozások:</h5>
              <ul className="space-y-1">
                {result.suggestions.map((s, i) => (
                  <li key={i} className="flex items-center text-sm text-slate-700 dark:text-gray-300">
                    <div className="w-1.5 h-1.5 bg-orange-500 rounded-full mr-2" />
                    {s}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ) : (
        <div className="border-2 border-dashed border-gray-300 dark:border-zinc-600 rounded-xl p-8 text-center hover:border-orange-500 dark:hover:border-orange-500 hover:bg-orange-50 dark:hover:bg-zinc-700/50 transition-colors cursor-pointer relative mb-6">
          <input 
            type="file" 
            accept="image/*" 
            onChange={handleFileChange} 
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
          <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <Upload size={24} />
          </div>
          <p className="font-medium text-gray-900 dark:text-white">Kattints vagy húzz ide egy ételfotót</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">JPG, PNG formátum</p>
        </div>
      )}

      {/* Email Form (Only shows after analysis) */}
      {result && step === 'analysis' && (
        <form onSubmit={handleSubmit} className="space-y-4 pt-4 border-t border-gray-100 dark:border-zinc-700">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">E-mail cím</label>
            <input 
              type="email" 
              required 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="etterem@pelda.hu"
              className="w-full px-4 py-2 border border-gray-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-gray-900 dark:text-white rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-colors"
            />
          </div>
          
          {emailError && (
             <div className="text-sm text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 p-2 rounded">
                {emailError}
             </div>
          )}

          <Button type="submit" className="w-full" isLoading={isSending}>
            Kérem a Profi Retusálást
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          <p className="text-xs text-center text-gray-500 dark:text-gray-400">
            A gombra kattintva elküldjük az elemzést a megadott címre.
          </p>
        </form>
      )}
    </div>
  );
};
