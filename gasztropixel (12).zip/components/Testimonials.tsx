import { useState, useEffect, type FC } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: "Nagy Gábor",
    role: "Tulajdonos, Burger Kinga",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100",
    quote: "Mióta a GasztroPixel retusálta a képeinket, a Wolt rendeléseink 20%-kal nőttek az első hónapban. Hihetetlen, mennyit számít a vizuális megjelenés.",
    rating: 5
  },
  {
    id: 2,
    name: "Kovács Anna",
    role: "Üzletvezető, Pizza Forte",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=100",
    quote: "Gyors, profi, és az előfizetés nyugalmat ad. Tudom, hogy ha változik az étlap, a képek mindig tökéletesek lesznek.",
    rating: 5
  },
  {
    id: 3,
    name: "Tóth Péter",
    role: "Séf, Bistro 42",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100",
    quote: "Az ingyenes próba győzött meg. A diagnózis pontos volt, a végeredmény pedig magáért beszél. Profi munka.",
    rating: 5
  }
];

export const Testimonials: FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  // Auto-advance
  useEffect(() => {
    const timer = setInterval(next, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-white dark:bg-zinc-950 py-20 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Ügyfeleink mondták</h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-400">
            Étteremvezetők és tulajdonosok tapasztalatai a GasztroPixelről.
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div className="overflow-hidden rounded-2xl bg-white dark:bg-zinc-800 shadow-xl border border-gray-100 dark:border-zinc-700 p-8 md:p-12 transition-all duration-300">
            <div className="absolute top-6 right-8 text-orange-100 dark:text-orange-900/20">
               <Quote size={80} />
            </div>
            
            <div className="relative z-10">
               <div 
                 key={currentIndex}
                 className="flex flex-col items-center text-center animate-in fade-in duration-500"
               >
                  <img 
                    src={testimonials[currentIndex].image} 
                    alt={testimonials[currentIndex].name}
                    className="w-20 h-20 rounded-full object-cover border-4 border-orange-100 dark:border-orange-900/30 mb-6 shadow-sm"
                  />
                  
                  <div className="flex gap-1 mb-6">
                    {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>

                  <blockquote className="text-xl md:text-2xl font-medium text-gray-800 dark:text-gray-100 mb-6 leading-relaxed italic">
                    "{testimonials[currentIndex].quote}"
                  </blockquote>

                  <div>
                    <div className="font-bold text-gray-900 dark:text-white text-lg">{testimonials[currentIndex].name}</div>
                    <div className="text-orange-600 dark:text-orange-400 font-medium uppercase tracking-wide text-sm">{testimonials[currentIndex].role}</div>
                  </div>
               </div>
            </div>
          </div>

          {/* Controls */}
          <button 
            onClick={prev}
            className="absolute top-1/2 -left-4 md:-left-16 -translate-y-1/2 p-3 rounded-full bg-white dark:bg-zinc-800 shadow-lg text-gray-400 hover:text-orange-600 dark:hover:text-orange-400 hover:scale-110 transition-all z-20 border border-gray-100 dark:border-zinc-700"
            aria-label="Previous testimonial"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button 
            onClick={next}
            className="absolute top-1/2 -right-4 md:-right-16 -translate-y-1/2 p-3 rounded-full bg-white dark:bg-zinc-800 shadow-lg text-gray-400 hover:text-orange-600 dark:hover:text-orange-400 hover:scale-110 transition-all z-20 border border-gray-100 dark:border-zinc-700"
            aria-label="Next testimonial"
          >
            <ChevronRight size={24} />
          </button>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2.5 rounded-full transition-all duration-300 ${
                  idx === currentIndex ? 'bg-orange-600 w-8' : 'bg-gray-200 dark:bg-zinc-700 w-2.5 hover:bg-gray-300 dark:hover:bg-zinc-600'
                }`}
                aria-label={`Go to testimonial ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};