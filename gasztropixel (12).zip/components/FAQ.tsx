import { useState, type FC } from 'react';
import { Plus, Minus } from 'lucide-react';

const faqs = [
  {
    question: "Miért van két külön díj? Mire elég a havi 2.490 Ft?",
    answer: "Az árazásunk két lépcsőből áll: a 9.890 Ft (Egyszeri Díj) a teljes étlapod képeinek professzionális beállítását és egységes stílusra hozását fedezi – ez az egyszeri nagy munka ára. A 2.490 Ft/hó (Fenntartó Díj) pedig a hozzáférés és a garancia díja. Ez fedezi a prioritást, a képek biztonsági archiválását, az ingyenes technikai karbantartást (pl. méretigazítás a Wolt változásakor) és azt, hogy sürgősségi esetben azonnal el tudd érni a szolgáltatást."
  },
  {
    question: "Mennyi idő alatt kapom meg a kész képeket?",
    answer: "Az egyszeri alapozást 3-5 munkanapon belül elvégezzük. A havi díjas tagságod miatt az új, sürgős képeket garantáltan 24–48 órán belül elküldjük."
  },
  {
    question: "Hoz-e a szolgáltatás több rendelést?",
    answer: "Igen. Az egységes, professzionális stílus növeli a márkád iránti bizalmat. A vevők a minőségi képek láttán sokkal nagyobb eséllyel adnak le rendelést nálad, a versenytársakkal szemben."
  },
  {
    question: "Milyen formátumban kapom meg a képeket?",
    answer: "A képeket nagy felbontású JPG formátumban adjuk át, külön mappákba rendezve: egy teljes felbontású verziót marketing célokra, és egy kifejezetten ételrendelő appokra (Wolt, Foodora) vágott verziót."
  },
  {
    question: "Hogyan juttatom el hozzátok a nyers fotókat?",
    answer: "A legjobb hír: neked semmilyen képet nem kell küldened. Ez a te kényelmedről szól! A mi feladatunk, hogy folyamatosan monitorozzuk a Foodora, a Wolt és a weboldalad frissítéseit. Amikor észreveszünk egy új, nyers fotót, amit feltöltöttél, automatikusan lementjük, feljavítjuk és visszatöltjük neked a kész változatot. Mi mindent megteszünk, hogy a képek hozzánk jussanak, hogy te csak a vállalkozásodra koncentrálhass."
  }
];

export const FAQ: FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-20 bg-white dark:bg-zinc-950 transition-colors duration-300">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Gyakori kérdések</h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-400">
            Minden, amit tudnod kell a szolgáltatásról.
          </p>
        </div>
        
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className="bg-gray-50 dark:bg-zinc-800 rounded-xl border border-gray-100 dark:border-zinc-700 overflow-hidden transition-all duration-200 hover:shadow-md dark:hover:shadow-zinc-700/20"
            >
              <button
                className="w-full px-6 py-5 text-left flex justify-between items-center focus:outline-none"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="font-semibold text-gray-900 dark:text-white pr-8">{faq.question}</span>
                {openIndex === index ? (
                  <Minus className="w-5 h-5 text-orange-600 dark:text-orange-500 flex-shrink-0" />
                ) : (
                  <Plus className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                )}
              </button>
              
              <div 
                className={`grid transition-all duration-300 ease-in-out ${
                  openIndex === index ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                }`}
              >
                <div className="overflow-hidden">
                    <div className="px-6 pb-6 text-gray-600 dark:text-gray-300 leading-relaxed">
                        {faq.answer}
                    </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};