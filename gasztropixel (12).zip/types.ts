export enum PricingTier {
  SETUP = 'SETUP',
  MAINTENANCE = 'MAINTENANCE'
}

export interface CartItem {
  id: string;
  name: string;
  price: number;
  type: PricingTier;
  recurring: boolean;
  description: string;
}

export interface AnalysisResult {
  feedback: string;
  suggestions: string[];
}